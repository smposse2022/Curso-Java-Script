/*Sumar de 3 en 3 - se me hace bucle infinito, no entiendo por qué
let ingresarNumero = parseInt(prompt("Ingresar Numero"));
for (let i = 1; i <= 100; i + 3) {
  let resultado = ingresarNumero + i;
  alert(ingresarNumero + " + " + i + " = " + resultado);
}
*/
let n1 = parseInt(prompt("Ingrese un número"));
let n2 = parseInt(prompt("Ingresar otro número"));
let resultado = n1 + n2;
while (n1 != "ESC") {
  console.log(resultado);
  n1 = prompt("Ingresar otro número");
}
